// src/components/battle/BattleScreen.jsx
/**
 * ============================================================================
 * FIXED BATTLESCREEN — now converts card IDs → card objects,
 * builds real enemies, and avoids instant victory.
 * ============================================================================
 */

import React, { useState, useEffect } from "react";
import Battlefield3D from "./Battlefield3D.jsx";
import "./BattleScreen.css";
import sheepImg from "/src/assets/sheep.jpg";
import { cards } from "../../data/cards.js";

let nextId = 1;

/* ----------------------------------------------------- */
/* CREATE BASE UNIT                                       */
/* ----------------------------------------------------- */
function createUnit(partial) {
  return {
    id: partial.id ?? `u_${nextId++}`,
    name: partial.name ?? "Unnamed Beast",
    cost: partial.cost ?? 1,
    attack: partial.attack ?? 1,
    health: partial.health ?? 1,
    maxHealth: partial.maxHealth ?? partial.health ?? 1,
    race: partial.race ?? "beast",
    rarity: partial.rarity ?? "common",
    stars: partial.stars ?? 1,
    text: partial.text ?? "",
    image: partial.image ?? null,
    imageTop: partial.imageTop ?? null,
    owner: partial.owner ?? "player",
    ...partial,
  };
}

/* ----------------------------------------------------- */
/* LEVEL SCALING FOR BATTLE                               */
/* ----------------------------------------------------- */
function evolveCardForBattle(card, upgradesMap = {}) {
  const steps = upgradesMap[card.id] || 0;
  const baseLevel = card.level ?? card.stars ?? 1;
  const maxLevel = card.maxLevel ?? 5;

  const level = Math.min(baseLevel + steps, maxLevel);

  const atkBase = card.baseAttack ?? card.attack ?? 1;
  const hpBase = card.baseHealth ?? card.health ?? 1;
  const atkPer = card.attackPerLevel ?? 1;
  const hpPer = card.healthPerLevel ?? 1;
  const delta = level - baseLevel;

  return {
    ...card,
    level,
    attack: atkBase + delta * atkPer,
    health: hpBase + delta * hpPer,
  };
}

/* ----------------------------------------------------- */
/* TUTORIAL UNITS                                         */
/* ----------------------------------------------------- */
function createTutorialSheep(i = 0) {
  return createUnit({
    id: `sheep_${i}`,
    name: "Sheep",
    attack: 1,
    health: 1,
    maxHealth: 1,
    race: "beast",
    rarity: "common",
    stars: 1,
    image: sheepImg,
    owner: "player",
  });
}

function createTutorialEnemy(catCard) {
  if (!catCard) {
    return createUnit({
      id: "tutorial_enemy_backup",
      name: "Sandwhisker Stalker",
      attack: 2,
      health: 2,
      maxHealth: 2,
      race: "beast",
      rarity: "common",
      stars: 1,
      image: "/src/assets/sandwhisker-lvl1.png",
      owner: "enemy",
    });
  }

  return createUnit({
    id: "tutorial_enemy_1",
    name: catCard.name,
    attack: catCard.baseAttack ?? catCard.attack,
    health: catCard.baseHealth ?? catCard.health,
    maxHealth: catCard.baseHealth ?? catCard.health,
    race: catCard.race,
    rarity: catCard.rarity,
    stars: catCard.stars ?? 1,
    image: catCard.image,
    owner: "enemy",
  });
}

/* ============================================================================
 * MAIN COMPONENT
 * ============================================================================
 */
export default function BattleScreen({
  playerDeck = [],
  upgrades = {},
  levelInfo,
  onExitBattle,
  onBattleComplete,
}) {
  /* ----------------------------------------------------- */
  /* DETECT IF THIS IS TUTORIAL                            */
  /* ----------------------------------------------------- */
  const isTutorial =
    levelInfo?.chapterId === "darkwood" &&
    (levelInfo?.levelId === 0 || levelInfo?.level?.id === 0);

  /* ----------------------------------------------------- */
  /* FIX: Convert deck IDs → real card objects             */
  /* ----------------------------------------------------- */
  const convertDeckIdsToCards = () => {
    return playerDeck
      .map((id) => cards.find((c) => c.id === id))
      .filter(Boolean); // remove undefined
  };

  /* ----------------------------------------------------- */
  /* BUILD ENEMY TEAM (normal levels)                      */
  /* ----------------------------------------------------- */
  const buildEnemyTeam = () => {
    if (!levelInfo?.chapter?.enemies) {
      console.warn("Missing enemy data for level → enemy field empty.");
      return [null, null, null];
    }

    const enemies = levelInfo.chapter.enemies.slice(0, 3);

    return enemies.map((enemy, i) =>
      createUnit({
        id: `enemy_${i}`,
        name: enemy.name,
        attack: enemy.power,
        health: enemy.power,
        maxHealth: enemy.power,
        race: "beast",
        rarity: "common",
        stars: 1,
        image: "/src/assets/default-enemy.png",
        owner: "enemy",
      })
    );
  };

  /* ----------------------------------------------------- */
  /* BUILD FULL INITIAL BATTLE STATE                       */
  /* ----------------------------------------------------- */
  const buildUnitsFromDeck = () => {
    /* -- Tutorial battle setup -- */
    if (isTutorial) {
      console.log("Battle: tutorial mode");
      let cat = cards.find((c) =>
        (c.id ?? "").toLowerCase().includes("sandwhisker")
      );

      if (!cat) {
        console.warn("Tutorial cat not found → using fallback.");
      }

      return {
        hand: [
          createTutorialSheep(1),
          createTutorialSheep(2),
          createTutorialSheep(3),
        ],
        field: [null, null, null],
        enemy: [createTutorialEnemy(cat), null, null],
      };
    }

    /* -- Normal battle -- */
    const deckCards = convertDeckIdsToCards();
    if (deckCards.length === 0) {
      console.warn("BattleScreen: playerDeck was empty → no battle units.");
      return { hand: [], field: [null, null, null], enemy: [null, null, null] };
    }

    const toUnit = (card) => {
      const evolved = evolveCardForBattle(card, upgrades);
      return createUnit({
        name: evolved.name,
        cost: evolved.cost,
        attack: evolved.attack,
        health: evolved.health,
        maxHealth: evolved.health,
        race: evolved.race,
        rarity: evolved.rarity,
        text: evolved.text,
        image: evolved.image,
        owner: "player",
        sourceCardId: card.id,
      });
    };

    return {
      hand: deckCards.slice(0, 3).map(toUnit),
      field: [null, null, null],
      enemy: buildEnemyTeam(),
    };
  };

  /* INITIAL STATE */
  const initial = buildUnitsFromDeck();
  const [playerHand, setPlayerHand] = useState(initial.hand);
  const [playerField, setPlayerField] = useState(initial.field);
  const [enemyField, setEnemyField] = useState(initial.enemy);

  const [playerGraveyard, setPlayerGraveyard] = useState([]);
  const [enemyGraveyard, setEnemyGraveyard] = useState([]);

  const [battlePhase, setBattlePhase] = useState("summonOrAttack");
  const [selectedAttackerId, setSelectedAttackerId] = useState(null);
  const [selectedTargetId, setSelectedTargetId] = useState(null);

  const [attackAnimations, setAttackAnimations] = useState([]);
  const [damageEffects, setDamageEffects] = useState([]);
  const [attackingUnitId, setAttackingUnitId] = useState(null);
  const [dyingUnits, setDyingUnits] = useState([]);

  const [battleResult, setBattleResult] = useState(null);
  const [hasReportedResult, setHasReportedResult] = useState(false);

  /* ----------------------------------------------------- */
  /* Reset battle on new deck                              */
  /* ----------------------------------------------------- */
  useEffect(() => {
    const fresh = buildUnitsFromDeck();
    setPlayerHand(fresh.hand);
    setPlayerField(fresh.field);
    setEnemyField(fresh.enemy);
    setBattlePhase("summonOrAttack");
    setSelectedAttackerId(null);
  }, [playerDeck, upgrades]);

  /* ----------------------------------------------------- */
  /* Card lookups                                          */
  /* ----------------------------------------------------- */
  const findUnitOnField = (owner, unitId) => {
    const field = owner === "player" ? playerField : enemyField;
    const index = field.findIndex((u) => u && u.id === unitId);
    return index === -1 ? null : { owner, index, unit: field[index] };
  };

  /* ----------------------------------------------------- */
  /* Summon logic                                          */
  /* ----------------------------------------------------- */
  const summonFromHandToField = (unitId) => {
    setPlayerHand((prev) => {
      const index = prev.findIndex((u) => u.id === unitId);
      if (index === -1) return prev;

      const card = prev[index];

      setPlayerField((prevField) => {
        const slot = prevField.findIndex((s) => !s);
        if (slot === -1) return prevField;

        const next = [...prevField];
        next[slot] = card;
        return next;
      });

      const newHand = [...prev];
      newHand.splice(index, 1);
      return newHand;
    });
  };

  /* ----------------------------------------------------- */
  /* Attack logic                                           */
  /* ----------------------------------------------------- */
  const resolveAttack = (atkInfo, defInfo) => {
    const { unit: atk, owner: atkOwner, index: atkIndex } = atkInfo;
    const { unit: def, owner: defOwner, index: defIndex } = defInfo;

    const dmgA = atk.attack;
    const dmgD = def.attack;

    const newHpAtk = Math.max(atk.health - dmgD, 0);
    const newHpDef = Math.max(def.health - dmgA, 0);

    setPlayerField((prev) => {
      if (atkOwner !== "player") return prev;
      const next = [...prev];
      next[atkIndex] = { ...atk, health: newHpAtk };
      return next;
    });

    setEnemyField((prev) => {
      if (defOwner !== "enemy") return prev;
      const next = [...prev];
      next[defIndex] = { ...def, health: newHpDef };
      return next;
    });

    const dying = [];
    if (newHpAtk <= 0) dying.push(atk.id);
    if (newHpDef <= 0) dying.push(def.id);

    setTimeout(() => {
      if (dying.length > 0) {
        setDyingUnits((o) => [...o, ...dying]);
      }
      setBattlePhase("summonOrAttack");
      setSelectedAttackerId(null);
    }, 600);
  };

  /* ----------------------------------------------------- */
  /* Handle click from 3D battlefield                       */
  /* ----------------------------------------------------- */
  const handle3DCardClick = ({ owner, zone, unitId }) => {
    if (battleResult) return;

    if (owner === "player" && zone === "hand") {
      summonFromHandToField(unitId);
      return;
    }

    if (owner === "player" && zone === "field") {
      setSelectedAttackerId(unitId);
      setBattlePhase("selectTarget");
      return;
    }

    if (owner === "enemy" && zone === "field" && battlePhase === "selectTarget") {
      const atk = findUnitOnField("player", selectedAttackerId);
      const def = findUnitOnField("enemy", unitId);
      if (atk && def) {
        setBattlePhase("resolving");
        resolveAttack(atk, def);
      }
    }
  };

  /* ----------------------------------------------------- */
  /* Victory / defeat detection                            */
  /* ----------------------------------------------------- */
  useEffect(() => {
    if (battleResult) return;

    const playerAlive =
      playerHand.length > 0 || playerField.some((u) => u && u.health > 0);

    const enemyAlive = enemyField.some((u) => u && u.health > 0);

    if (!enemyAlive && playerAlive) setBattleResult("victory");
    else if (!playerAlive && enemyAlive) setBattleResult("defeat");
  }, [playerHand, playerField, enemyField]);

  /* ----------------------------------------------------- */
  /* Notify parent ONCE                                     */
  /* ----------------------------------------------------- */
  useEffect(() => {
    if (battleResult && !hasReportedResult) {
      const reward = battleResult === "victory" ? 150 : 0;
      onBattleComplete?.(battleResult, levelInfo, reward);
      setHasReportedResult(true);
    }
  }, [battleResult, hasReportedResult]);

  /* ====================================================================== */
  /* RENDER                                                                  */
  /* ====================================================================== */
  return (
    <div className="battle-screen-container">
      <Battlefield3D
        levelInfo={levelInfo}
        playerField={playerField}
        enemyField={enemyField}
        playerHand={playerHand}
        onCardClick={handle3DCardClick}
        selectedAttackerId={selectedAttackerId}
        selectedTargetId={selectedTargetId}
        attackAnimations={attackAnimations}
        damageEffects={damageEffects}
        dyingUnits={dyingUnits}
        attackingUnitId={attackingUnitId}
        battlePhase={battlePhase}
        isPlayerTurn={true}
      />

      {battleResult && (
        <div className="battle-result-overlay">
          <div className={`battle-result-panel ${battleResult}`}>
            <div className="battle-result-header">
              {battleResult === "victory" ? "Victory" : "Defeat"}
            </div>

            <p className="battle-result-text">
              {battleResult === "victory"
                ? "Your beasts stand victorious!"
                : "You have fallen—but will rise again."}
            </p>

            {battleResult === "victory" && (
              <div className="battle-result-rewards">
                <div className="battle-result-reward-label">Gold Earned</div>
                <div className="battle-result-gold-amount">+150</div>
              </div>
            )}

            <div className="battle-result-actions">
              <button className="battle-result-btn" onClick={onExitBattle}>
                Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
