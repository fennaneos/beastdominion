// src/components/fx/curvyarrow.jsx

import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export default function CurvyArrow({ start, end, color = '#ff7b3d', opacity = 0.8, width = 0.1 }) {
  const arrowRef = useRef();
  
  // Create a curved path from start to end
  const { curve, points } = useMemo(() => {
    const startPoint = new THREE.Vector3(...start);
    const endPoint = new THREE.Vector3(...end);
    
    // Calculate control points for a quadratic bezier curve
    const midPoint = new THREE.Vector3()
      .addVectors(startPoint, endPoint)
      .multiplyScalar(0.5);
    
    // Add some height to make it curved
    midPoint.y += 2;
    
    const curve = new THREE.QuadraticBezierCurve3(
      startPoint,
      midPoint,
      endPoint
    );
    
    const points = curve.getPoints(50);
    
    return { curve, points };
  }, [start, end]);
  
  // Create tube geometry from the curve
  const geometry = useMemo(() => {
    return new THREE.TubeGeometry(curve, 20, width, 8, false);
  }, [curve, width]);
  
  // Animate the arrow
  useFrame((state) => {
    if (!arrowRef.current) return;
    
    // Add a subtle pulsing effect
    const scale = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.05;
    arrowRef.current.scale.set(scale, scale, scale);
  });
  
  return (
    <mesh ref={arrowRef} geometry={geometry}>
      <meshBasicMaterial 
        color={color} 
        transparent 
        opacity={opacity} 
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}