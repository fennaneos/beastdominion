// src/tutorial/TutorialScreen.jsx
/**
 * ============================================================================
 * TUTORIAL SCREEN
 * Self-contained battle used ONLY for the guided tutorial.
 *
 * - Does NOT use playerDeck / upgrades / levelInfo
 * - Always spawns a fixed scenario: 3 sheep vs 1 enemy
 * - Uses existing Battlefield3D for rendering & card clicks
 * ============================================================================
 */

import React, { useState, useEffect } from "react";
import Battlefield3D from "../components/battle/Battlefield3D.jsx";
import "./TutorialScreen.css";
import sheepImg from "/src/assets/sheep.jpg";
import { cards } from "../data/cards.js";

let nextId = 1;

/* ----------------------------------------------------- */
/* BASE UNIT                                             */
/* ----------------------------------------------------- */
function createUnit(partial) {
  return {
    id: partial.id ?? `u_${nextId++}`,
    name: partial.name ?? "Unnamed Beast",
    cost: partial.cost ?? 1,
    attack: partial.attack ?? 1,
    health: partial.health ?? 1,
    maxHealth: partial.maxHealth ?? partial.health ?? 1,
    race: partial.race ?? "beast",
    rarity: partial.rarity ?? "common",
    stars: partial.stars ?? 1,
    text: partial.text ?? "",
    image: partial.image ?? null,
    imageTop: partial.imageTop ?? null,
    owner: partial.owner ?? "player",
    ...partial,
  };
}

/* ----------------------------------------------------- */
/* TUTORIAL UNITS                                        */
/* ----------------------------------------------------- */
function createTutorialSheep(i = 0) {
  return createUnit({
    id: `tutorial_sheep_${i}`,
    name: "Sheep",
    attack: 1,
    health: 1,
    maxHealth: 1,
    race: "beast",
    rarity: "common",
    stars: 1,
    image: sheepImg,
    owner: "player",
  });
}

function createTutorialEnemy() {
  const cat = cards.find((c) =>
    (c.id ?? "").toLowerCase().includes("sandwhisker")
  );

  if (!cat) {
    return createUnit({
      id: "tutorial_enemy_backup",
      name: "Sandwhisker Stalker",
      attack: 2,
      health: 2,
      maxHealth: 2,
      race: "beast",
      rarity: "common",
      stars: 1,
      image: "/src/assets/sandwhisker-lvl1.png",
      owner: "enemy",
    });
  }

  return createUnit({
    id: "tutorial_enemy_1",
    name: cat.name,
    attack: cat.baseAttack ?? cat.attack ?? 2,
    health: cat.baseHealth ?? cat.health ?? 2,
    maxHealth: cat.baseHealth ?? cat.health ?? 2,
    race: cat.race,
    rarity: cat.rarity,
    stars: cat.stars ?? 1,
    image: cat.image,
    owner: "enemy",
  });
}

/* ----------------------------------------------------- */
/* INITIAL TUTORIAL STATE                                */
/* ----------------------------------------------------- */
function buildInitialTutorialState() {
  return {
    hand: [
      createTutorialSheep(1),
      createTutorialSheep(2),
      createTutorialSheep(3),
      createTutorialSheep(4),
      createTutorialSheep(5),
      createTutorialSheep(6),
    ],
    field: [null, null, null],
    enemy: [createTutorialEnemy(), null, null],
  };
}

/* ============================================================================
 * MAIN TUTORIAL SCREEN COMPONENT
 * ========================================================================== */
export default function TutorialScreen({
  // App passes more stuff, we only care about:
  onExitBattle,
  onBattleComplete,
}) {
  /* ----------------------------------------------------- */
  /* FIXED TUTORIAL FLAG                                  */
  /* ----------------------------------------------------- */
  const isTutorial = true;

  /* ----------------------------------------------------- */
  /* INITIAL STATE                                         */
  /* ----------------------------------------------------- */
  const initial = buildInitialTutorialState();
  const [playerHand, setPlayerHand] = useState(initial.hand);
  const [playerField, setPlayerField] = useState(initial.field);
  const [enemyField, setEnemyField] = useState(initial.enemy);

  const [playerGraveyard, setPlayerGraveyard] = useState([]);
  const [enemyGraveyard, setEnemyGraveyard] = useState([]);

  const [battlePhase, setBattlePhase] = useState("summonOrAttack");
  const [selectedAttackerId, setSelectedAttackerId] = useState(null);
  const [selectedTargetId, setSelectedTargetId] = useState(null);

  const [attackAnimations, setAttackAnimations] = useState([]);
  const [damageEffects, setDamageEffects] = useState([]);
  const [attackingUnitId, setAttackingUnitId] = useState(null);
  const [dyingUnits, setDyingUnits] = useState([]);

  const [battleResult, setBattleResult] = useState(null);
  const [hasReportedResult, setHasReportedResult] = useState(false);

  /* ----------------------------------------------------- */
  /* Lookup helper                                         */
  /* ----------------------------------------------------- */
  const findUnitOnField = (owner, unitId) => {
    const field = owner === "player" ? playerField : enemyField;
    const index = field.findIndex((u) => u && u.id === unitId);
    return index === -1 ? null : { owner, index, unit: field[index] };
  };

  /* ----------------------------------------------------- */
  /* Summon from hand → first empty slot                   */
  /* ----------------------------------------------------- */
  const summonFromHandToField = (unitId) => {
    setPlayerHand((prevHand) => {
      const index = prevHand.findIndex((u) => u.id === unitId);
      if (index === -1) return prevHand;

      const card = prevHand[index];

      setPlayerField((prevField) => {
        const slot = prevField.findIndex((s) => !s);
        if (slot === -1) return prevField; // no space

        const next = [...prevField];
        next[slot] = card;
        return next;
      });

      const newHand = [...prevHand];
      newHand.splice(index, 1);
      return newHand;
    });
  };

  /* ----------------------------------------------------- */
  /* Attack resolution                                     */
  /* ----------------------------------------------------- */
  const resolveAttack = (atkInfo, defInfo) => {
    const { unit: atk, owner: atkOwner, index: atkIndex } = atkInfo;
    const { unit: def, owner: defOwner, index: defIndex } = defInfo;

    const dmgA = atk.attack;
    const dmgD = def.attack;

    const newHpAtk = Math.max(atk.health - dmgD, 0);
    const newHpDef = Math.max(def.health - dmgA, 0);

    setPlayerField((prev) => {
      if (atkOwner !== "player") return prev;
      const next = [...prev];
      next[atkIndex] = { ...atk, health: newHpAtk };
      return next;
    });

    setEnemyField((prev) => {
      if (defOwner !== "enemy") return prev;
      const next = [...prev];
      next[defIndex] = { ...def, health: newHpDef };
      return next;
    });

    const dying = [];
    if (newHpAtk <= 0) dying.push(atk.id);
    if (newHpDef <= 0) dying.push(def.id);

    // Small delay to let any attack animation play
    setTimeout(() => {
      if (dying.length > 0) {
        setDyingUnits((o) => [...o, ...dying]);
      }
      setBattlePhase("summonOrAttack");
      setSelectedAttackerId(null);
      setSelectedTargetId(null);
    }, 600);
  };

  /* ----------------------------------------------------- */
  /* Handle clicks from 3D battlefield                     */
  /* ----------------------------------------------------- */
  const handle3DCardClick = ({ owner, zone, unitId }) => {
    if (battleResult) return;

    // 1) Summoning from hand
    if (owner === "player" && zone === "hand") {
      summonFromHandToField(unitId);
      return;
    }

    // 2) Selecting attacker
    if (owner === "player" && zone === "field") {
      setSelectedAttackerId(unitId);
      setBattlePhase("selectTarget");
      return;
    }

    // 3) Selecting target & resolving
    if (
      owner === "enemy" &&
      zone === "field" &&
      battlePhase === "selectTarget"
    ) {
      const atk = findUnitOnField("player", selectedAttackerId);
      const def = findUnitOnField("enemy", unitId);
      if (atk && def) {
        setBattlePhase("resolving");
        setSelectedTargetId(unitId);
        resolveAttack(atk, def);
      }
    }
  };

  /* ----------------------------------------------------- */
  /* Victory / defeat detection                            */
  /* ----------------------------------------------------- */
  useEffect(() => {
    if (battleResult) return;

    const playerAlive =
      playerHand.length > 0 || playerField.some((u) => u && u.health > 0);

    const enemyAlive = enemyField.some((u) => u && u.health > 0);

    if (!enemyAlive && playerAlive) {
      setBattleResult("victory");
    } else if (!playerAlive && enemyAlive) {
      setBattleResult("defeat");
    }
  }, [playerHand, playerField, enemyField, battleResult]);

  /* ----------------------------------------------------- */
  /* Notify parent *once* when finished                     */
  /* ----------------------------------------------------- */
  useEffect(() => {
    if (battleResult && !hasReportedResult) {
      const levelInfo = { type: "tutorial" }; // minimal stub
      const reward = battleResult === "victory" ? 150 : 0;
      onBattleComplete?.(battleResult, levelInfo, reward);
      setHasReportedResult(true);
    }
  }, [battleResult, hasReportedResult, onBattleComplete]);

  /* ====================================================================== */
  /* RENDER                                                                 */
  /* ====================================================================== */
  return (
    <div className="battle-screen-container">
      <Battlefield3D
        levelInfo={{ type: "tutorial" }}
        playerField={playerField}
        enemyField={enemyField}
        playerHand={playerHand}
        playerGraveyard={playerGraveyard}
        enemyGraveyard={enemyGraveyard}
        onCardClick={handle3DCardClick}
        selectedAttackerId={selectedAttackerId}
        selectedTargetId={selectedTargetId}
        attackAnimations={attackAnimations}
        damageEffects={damageEffects}
        dyingUnits={dyingUnits}
        attackingUnitId={attackingUnitId}
        battlePhase={battlePhase}
        isPlayerTurn={true}
      />

      {battleResult && (
        <div className="battle-result-overlay">
          <div className={`battle-result-panel ${battleResult}`}>
            <div className="battle-result-header">
              {battleResult === "victory" ? "Victory" : "Defeat"}
            </div>

            <p className="battle-result-text">
              {battleResult === "victory"
                ? "Your beasts stand victorious!"
                : "You have fallen—but will rise again."}
            </p>

            {battleResult === "victory" && (
              <div className="battle-result-rewards">
                <div className="battle-result-reward-label">Gold Earned</div>
                <div className="battle-result-gold-amount">+150</div>
              </div>
            )}

            <div className="battle-result-actions">
              <button className="battle-result-btn" onClick={onExitBattle}>
                Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
