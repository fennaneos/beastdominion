// src/tutorial/TutorialController.js
// Encapsulates tutorial step logic, click permissions, and scripted attacks.

import {
  createEmitter,
  resolveDamage,
  cloneBattleState,
} from "./TutorialUtils";

const countField = (slots) =>
  (slots || []).filter((s) => s && s.card).length;

const STEPS = [
  {
    id: "summon_frontline",
    title: "Summon Your Frontline",
    description:
      "From your hand below, choose three sheep to stand in the middle of the arena.",
    focus: "playerHand",
    allowClick: (info) =>
      info.side === "player" && info.zone === "hand",
    canContinue: (battle) => countField(battle.player.field) >= 3,
  },
  {
    id: "choose_attacker",
    title: "Battle Begins – Choose Your Attacker",
    description:
      "Battle begins. Pick one of your frontline sheep to attack.",
    focus: "playerField",
    allowClick: (info) =>
      info.side === "player" && info.zone === "field",
    canContinue: (battle, tutorial) =>
      tutorial.attackerSlot !== null &&
      battle.player.field[tutorial.attackerSlot]?.card,
  },
  {
    id: "choose_target",
    title: "Choose an Enemy Target",
    description:
      "Now choose which enemy beast your attacker should strike. The glowing arrows show all valid targets.",
    focus: "enemyField",
    allowClick: (info) =>
      info.side === "enemy" && info.zone === "field",
    canContinue: (battle, tutorial) =>
      tutorial.targetSlot !== null &&
      battle.enemy.field[tutorial.targetSlot]?.card,
  },
  {
    id: "confirm_attack",
    title: "Launch the Attack",
    description:
      "Your attacker and the chosen target clash! Press ATTACK to resolve the blow.",
    focus: "attackButton",
    hasAttackButton: true,
    allowClick: null,
    canContinue: (battle, tutorial) => tutorial.attackExecuted === true,
    isFinal: true,
  },
];

export class TutorialController {
  constructor() {
    this.emitter = createEmitter();
    this.stepIndex = 0;
    this.sounds = null;
  }

  on(type, fn) {
    this.emitter.on(type, fn);
  }
  off(type, fn) {
    this.emitter.off(type, fn);
  }
  emit(type, payload) {
    this.emitter.emit(type, payload);
  }

  attachSounds(sounds) {
    this.sounds = sounds;
  }

  getCurrentStep() {
    const base = STEPS[this.stepIndex] || STEPS[0];
    return { ...base, index: this.stepIndex };
  }

  bootstrapBattle(deck) {
    const battle = {
      turn: "player",
      player: {
        hand: deck.playerHand.slice(),
        field: [null, null, null], // 3 middle slots
        hp: 20,
      },
      enemy: {
        hand: [],
        field: deck.enemyField.map((card) => ({ card })),
        hp: 20,
      },
      fx: [],
    };
    this.emit("battle", battle);
    return battle;
  }

  start(tutorialState, battleState) {
    this.emit("step", this.getCurrentStep());
    this._emitLock(battleState, tutorialState);
    return tutorialState;
  }

  canGoNext(battle, tutorial) {
    const step = STEPS[this.stepIndex];
    if (!step || !step.canContinue) return true;
    return step.canContinue(battle, tutorial);
  }

  handleCardClick(info, battleState, tutorialState) {
    const step = STEPS[this.stepIndex];
    if (!step) return null;
    if (step.allowClick && !step.allowClick(info)) {
      return null;
    }

    const battle = cloneBattleState(battleState);
    const tutorial = { ...tutorialState };

    switch (step.id) {
      case "summon_frontline":
        this._summonFromHand(info.index, battle);
        break;
      case "choose_attacker":
        tutorial.attackerSlot = info.index;
        tutorial.targetSlot = null;
        tutorial.attackExecuted = false;
        break;
      case "choose_target":
        tutorial.targetSlot = info.index;
        tutorial.attackExecuted = false;
        break;
      default:
        break;
    }

    this.emit("battle", battle);
    this._emitLock(battle, tutorial);
    this.emit("step", this.getCurrentStep());
    return { battle, tutorial };
  }

  executeAttack(battleState, tutorialState) {
    const step = STEPS[this.stepIndex];
    if (!step || step.id !== "confirm_attack") return null;

    const battle = cloneBattleState(battleState);
    const tutorial = { ...tutorialState };

    const aIdx = tutorial.attackerSlot;
    const tIdx = tutorial.targetSlot;
    const attackerSlot = battle.player.field[aIdx];
    const defenderSlot = battle.enemy.field[tIdx];

    if (!attackerSlot?.card || !defenderSlot?.card) return null;

    attackerSlot.isAttacking = true;
    defenderSlot.tookDamage = true;

    const result = resolveDamage(attackerSlot.card, defenderSlot.card);

    if (result.attackerDead) attackerSlot.isDead = true;
    if (result.defenderDead) defenderSlot.isDead = true;

    battle.fx.push({
      id: "hit-" + Date.now(),
      type: "damage",
      amount: result.defenderDamage,
      position: [0, 1.6, -2],
    });

    if (this.sounds) {
      this.sounds.swordClash?.();
      this.sounds.impact?.();
    }

    tutorial.attackExecuted = true;

    this.emit("battle", battle);
    this._emitLock(battle, tutorial);
    this.emit("step", this.getCurrentStep());
    return { battle, tutorial };
  }

  nextStep(battleState, tutorialState) {
    if (!this.canGoNext(battleState, tutorialState)) {
      return false;
    }

    if (this.stepIndex < STEPS.length - 1) {
      this.stepIndex += 1;
      this.emit("step", this.getCurrentStep());
      this._emitLock(battleState, tutorialState);
      return false;
    }

    this._emitLock(battleState, tutorialState);
    return true;
  }

  _summonFromHand(handIndex, battle) {
    const card = battle.player.hand[handIndex];
    if (!card) return;
    const emptyIndex = battle.player.field.findIndex((s) => !s || !s.card);
    if (emptyIndex === -1) return;
    battle.player.field[emptyIndex] = { card };
    battle.player.hand[handIndex] = null;
  }

  _emitLock(battle, tutorial) {
    const locked = !this.canGoNext(battle, tutorial);
    this.emit("lock", locked);
  }
}
